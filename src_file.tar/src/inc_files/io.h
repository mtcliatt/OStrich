#if !defined(__cplusplus)
#include <stdbool.h> /* C doesn't have booleans by default. */
#endif
#include <stddef.h>
#include <stdint.h>

enum vga_color;
uint8_t make_color         (enum vga_color, enum vga_color);
uint16_t make_vgaentry     (char, uint8_t);
size_t strlen              (const char*);
void terminal_initialize   ();
void terminal_setcolor     (uint8_t);
void terminal_putentryat   (char, uint8_t, size_t, size_t);
void terminal_putchar      (char );
void terminal_writestring  (void *, void *, void *, void *, void *, void *);
void monitor_clear         (void *, void *, void *, void *, void *, void *);
void start_screen          ();
void wait                  (long);
