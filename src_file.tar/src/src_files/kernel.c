#include "../inc_files/kernel.h"


// With both & and ()
int (*calls[2]) (void *, void *, void *, void *, void *, void *) = 
	{
		&terminal_write(),
		&monitor_clear()
	};

	
/* Without () but with & 
int (*calls[2]) (void *, void *, void *, void *, void *, void *) = 
	{
		&terminal_write,
		&monitor_clear
	};
*/

/* Without & and ()
int (*calls[2]) (void *, void *, void *, void *, void *, void *) = 
	{
		terminal_write,
		monitor_clear
	};
*/

/* Without & but with ()
int (*calls[2]) (void *, void *, void *, void *, void *, void *) = 
	{
		terminal_write(),
		monitor_clear()
	};
*/

void kernel_main()
{
	terminal_initialize();
	/* Since there is no support for newlines in terminal_putchar yet, \n will
	   produce some VGA specific character instead. This is normal. */
	terminal_writestring("Hello, kernel World!\nThe kernel is t3h lulz2!\n", NULL, NULL, NULL, NULL, NULL);
	terminal_writestring("\nPrinting twice works", NULL, NULL, NULL, NULL, NULL);
	monitor_clear(NULL, NULL, NULL, NULL, NULL, NULL);
	terminal_writestring("Clearing worked if this is the only line of text.\n\n\nAnd this one\n\n\n\n\n\n\n\n\n\n\n", NULL, NULL, NULL, NULL, NULL);
	monitor_clear(NULL, NULL, NULL, NULL, NULL, NULL);
	start_screen(50);
	monitor_clear(NULL, NULL, NULL, NULL, NULL, NULL);
	terminal_writestring("OStrich >>>", NULL, NULL, NULL, NULL, NULL);

	//(*calls[SYSCALL_WRITE]) ("hello hopefully", NULL, NULL, NULL, NULL, NULL);
}
